var a_current = 0;
var b_current = 0;
var c_current = 0;

var a_dif = 0
var b_dif = 0
var c_dif = 0

$(document).ready(function(){

  $("#floorSelect li").click(function(){
  
    // get the floor
    var floor = parseInt($(this).data("floor")),
    
    height = floor*5,
    
    a_dif = Math.abs(a_current-floor)
    b_dif = Math.abs(b_current-floor)
    c_dif = Math.abs(c_current-floor)
    
    var selectedE = 'a'
    
    if(a_dif > b_dif){
        selectedE = 'b'
    }
    if(b_dif > c_dif){
        selectedE = 'c'
    }
    
    //    if(floor == current) return;
    console.log(selectedE)
    if(selectedE == 'a'){

        animate = Math.abs(a_current-floor)*100;

        $("#rightDoor").removeClass("active-right");   
        $("#leftDoor").removeClass("active-left");  
    
        setTimeout(function() {
            $("#elevatorContainer").css("transition","all "+animate+"ms linear");
            $("#elevatorContainer").css("bottom",height+"%");
            
            a_current = floor;
            
            setTimeout(function(){
        
                $("#rightDoor").addClass("active-right");   
                $("#leftDoor").addClass("active-left");  
        
            },animate);
        },500);
    }

    if(selectedE == 'b'){

        animate = Math.abs(b_current-floor)*100;

        $("#rightDoor1").removeClass("active-right1");   
        $("#leftDoor1").removeClass("active-left1");  
    
        setTimeout(function() {
            $("#elevatorContainer1").css("transition","all "+animate+"ms linear");
            $("#elevatorContainer1").css("bottom",height+"%");
            
            b_current = floor;
            
            setTimeout(function(){
        
                $("#rightDoor1").addClass("active-right1");   
                $("#leftDoor1").addClass("active-left1");  
        
            },animate);
        },500);
    }

    if(selectedE == 'c'){

        animate = Math.abs(c_current-floor)*100;

        $("#rightDoor2").removeClass("active-right2");   
        $("#leftDoor2").removeClass("active-left2");  
    
        setTimeout(function() {
            $("#elevatorContainer2").css("transition","all "+animate+"ms linear");
            $("#elevatorContainer2").css("bottom",height+"%");
            
            c_current = floor;
            
            setTimeout(function(){
        
                $("#rightDoor2").addClass("active-right2");   
                $("#leftDoor2").addClass("active-left2");  
        
            },animate);
        },500);
    }

  });

});